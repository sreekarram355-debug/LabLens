# LabLens

A responsive React frontend for the LabLens account screens, recreated from the publicly visible Base44 app.

## Screens
- Login
- Create account
- Forgot password
- Navigation between screens
- Basic form validation and password confirmation

## Run locally

You need Node.js installed.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Project files

```text
LabLens/
├── index.html
├── package.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── AuthForm.jsx
    └── styles.css
```

## Important: backend not connected

This repository is a frontend starter. The forms currently validate input in the browser and show demonstration messages. They do not create real accounts, authenticate users, send password-reset emails, or sign in with Google.

To enable those features, connect an authentication backend (for example, a suitable auth provider) and configure it securely. Never commit private API keys, service-role keys, passwords, or other secrets to a public GitHub repository.
