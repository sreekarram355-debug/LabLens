import { useState } from 'react';

export default function AuthForm({ page, navigate }) {
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);

  function showMessage(message) {
    setNotice(message);
    setBusy(false);
  }

  function handleSubmit(event) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);

    if (page === 'register' && form.get('password') !== form.get('confirmPassword')) {
      showMessage('Your passwords do not match. Please try again.');
      return;
    }

    if (page === 'login') {
      showMessage('Frontend demo only: connect an authentication service to log in.');
    } else if (page === 'register') {
      showMessage('Frontend demo only: connect an authentication service to create an account.');
    } else {
      showMessage('Frontend demo only: connect an email service to send a reset link.');
    }
  }

  const isLogin = page === 'login';
  const isRegister = page === 'register';
  const isForgot = page === 'forgot-password';

  return (
    <div>
      <p className="eyebrow">{isForgot ? 'ACCOUNT HELP' : 'LABLENS'}</p>
      <h1>{isLogin ? 'Welcome back' : isRegister ? 'Create your account' : 'Reset password'}</h1>
      <p className="subtitle">
        {isLogin
          ? 'Log in to continue to your workspace.'
          : isRegister
            ? 'Sign up to get started.'
            : "Enter your email address and we'll help you reset your password."}
      </p>

      {!isForgot && (
        <>
          <button className="google-button" type="button" onClick={() => showMessage('Google sign-in requires OAuth setup with an authentication provider.')}>
            <span className="google-g">G</span>
            Continue with Google
          </button>
          <div className="separator"><span>or</span></div>
        </>
      )}

      <form onSubmit={handleSubmit}>
        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" required />

        {!isForgot && (
          <>
            <label htmlFor="password">Password</label>
            <input
              id="password"
              name="password"
              type="password"
              placeholder={isRegister ? 'At least 8 characters' : 'Enter your password'}
              minLength={isRegister ? 8 : undefined}
              autoComplete={isRegister ? 'new-password' : 'current-password'}
              required
            />
          </>
        )}

        {isRegister && (
          <>
            <label htmlFor="confirmPassword">Confirm password</label>
            <input id="confirmPassword" name="confirmPassword" type="password" placeholder="Enter your password again" minLength={8} autoComplete="new-password" required />
          </>
        )}

        {isLogin && (
          <div className="form-row">
            <span />
            <a href="#forgot-password" onClick={() => navigate('forgot-password')}>Forgot password?</a>
          </div>
        )}

        <button className="primary-button" type="submit" disabled={busy}>
          {isLogin ? 'Log in' : isRegister ? 'Create account' : 'Send reset link'}
        </button>
      </form>

      <p className="switch-copy">
        {isLogin && <>Don't have an account? <a href="#register" onClick={() => navigate('register')}>Create one</a></>}
        {isRegister && <>Already have an account? <a href="#login" onClick={() => navigate('login')}>Log in</a></>}
        {isForgot && <a href="#login" onClick={() => navigate('login')}>← Back to log in</a>}
      </p>

      {notice && <p className="notice" role="status">{notice}</p>}
    </div>
  );
}
