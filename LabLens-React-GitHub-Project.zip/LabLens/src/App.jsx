import { useEffect, useState } from 'react';
import AuthForm from './AuthForm.jsx';

function readPage() {
  const path = window.location.hash.replace('#', '').replace('/', '');
  return ['login', 'register', 'forgot-password'].includes(path) ? path : 'login';
}

export default function App() {
  const [page, setPage] = useState(readPage);

  useEffect(() => {
    const onHashChange = () => setPage(readPage());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  function navigate(nextPage) {
    window.location.hash = nextPage;
    setPage(nextPage);
  }

  return (
    <main className="page-shell">
      <section className="auth-card">
        <div className="brand-mark" aria-label="LabLens logo">
          <svg viewBox="0 0 48 48" aria-hidden="true">
            <circle cx="24" cy="24" r="20" />
            <path d="M15 17h18M15 24h18M15 31h11" />
            <circle className="brand-dot" cx="34" cy="31" r="3.5" />
          </svg>
        </div>
        <AuthForm page={page} navigate={navigate} />
        <p className="footer-note">A LabLens interface</p>
      </section>
      <p className="page-caption">Simple access to your LabLens workspace</p>
    </main>
  );
}
